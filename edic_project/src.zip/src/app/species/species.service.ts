import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ISpecies } from './species.model';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})

export class SpeciesService {

  API_KEY = 'YOUR_API_KEY';

  private _url = 'http://api.gbif.org/v1/species/suggest?';

  constructor(private httpClient: HttpClient) { }

  getSpecies(): Observable<ISpecies[]> {
    // tslint:disable-next-line: max-line-length
    const url = this._url;
    return this.httpClient.get<ISpecies[]>(url);
  }
}










