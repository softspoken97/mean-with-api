export interface ILayers {
  _id: string;
  url: string;
  epsg: number;
  id: number;
  name: string;
  modificationTime: Date;
}
